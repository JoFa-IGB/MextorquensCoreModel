epsilon=1e-10;
basic_color=[0.7         0.7         0.7];
cr_color=[0.5         0.5           1];
br_color=[1         0.2         0.2];
nbr_color=[0.7         0.7         0.7];
text_color=[0  0  0];
macro_synth_color=[0  0  1];
macro_color=[0.9         0.9         0.5];
box_reaction_width=[0.02        0.03       0.015];
box_reaction_height=[0.01        0.03        0.01];
box_macro_width=[0.04        0.03        0.04];
box_macro_height=[0.02        0.03        0.04];
fontsize_reaction=[4  11   4];
fontsize_macro=[11  11  11];
fluxmaps={
'Central Carbon and Energy Metabolism','20240801_MexCore_Fluxmap_V1_CCM.png'
'Amino acid Metabolism','20240801_MexCore_Fluxmap_V1_BM.png'
};
